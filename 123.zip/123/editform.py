# -*- coding: utf-8 -*-
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField, TextAreaField
from wtforms.fields.html5 import URLField
from wtforms.validators import DataRequired
 
 
class EditForm(FlaskForm):
    photo = URLField('URL для аватарки')
    status = TextAreaField('Полная ссылка на ваш вк')
    submit = SubmitField('Сохранить')