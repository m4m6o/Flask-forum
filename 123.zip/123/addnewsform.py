# -*- coding: utf-8 -*-
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, TextAreaField
from wtforms.validators import DataRequired
 
class AddNewsForm(FlaskForm):
    title = StringField('Предмет', validators=[DataRequired()])
    content = TextAreaField('Опишите, что вам нужно', validators=[DataRequired()])
    submit = SubmitField('Спросить')